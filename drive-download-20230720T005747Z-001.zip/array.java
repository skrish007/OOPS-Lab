import java.util.*;
class arraylist{
	public static void main (String args[])
	{
		int ch;
		Scanner oj =new Scanner(System.in);
		ArrayList<String> item = new ArrayList<String> ();
		System.out.println();
		do{
			System.out.println("Select your Options \2  \n 1. Add \n 2. Display \n 3. Sort \n 4. Remove");
			ch=oj.nextInt();
			switch (ch)
			{
				case 1:
				String a;
				System.out.println("Enter The Item");
				a=oj.next();
				item.add(a);
				break;
				case 2:
				System.out.println(item);
				break;
				case 3:
					Collections.sort(item);//Sorting the List
					System.out.println("Sorted List is :-");
					for(String i : item)//for each loop for accessing list items
					{
						System.out.println(i);
					}
				break;
				case 4:
					System.out.println("Enter position of item to remove");
					int j=oj.nextInt();
					String r= item.remove(j);
					System.out.println(r + "Is Removed From list");
					break;
				case 5:
					System.out.println("Maximum Element in ArrayList = "+ Collections.max(item));
					break;
				case 0:
					System.out.println("Exiting");
				break;
			}
		}while(ch!=0);
	}
}