import java.util.*;
class fibo implements Runnable
{
	public void run()
	{
		int a=0,b=1;
		int lim,sum=0;
		Scanner x=new Scanner(System.in);
		System.out.println("******** FIBONACCI SERIES *************");
		System.out.println("Enter the number of terms :");