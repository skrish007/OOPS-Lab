import java.io.*;
import java.util.*;
class linkedhash {
    public static void main(String[] args)
    {
 
	Set<String> linkedhash = new LinkedHashSet<String>();
	String a,b,c,d;
	Scanner x = new Scanner(System.in);
	System.out.println("Enter the Strings:");
	a=x.next();
	b=x.next();
	c=x.next();
	d=x.next();
    linkedhash.add(a);
    linkedhash.add(b);
    linkedhash.add(c);
    linkedhash.add(d);
    
	 System.out.println("Size of LinkedHashSet = "+ linkedhash.size());
     System.out.println("Original LinkedHashSet:"+ linkedhash);
	 System.out.println("Removing the first from LinkedHashSet: "+ linkedhash.remove(a));
     System.out.println("Checking if word ABC is present="+ linkedhash.contains("ABC"));
 
     System.out.println("Updated LinkedHashSet: "+ linkedset);
    }
}