import java.util.*;
class fibo implements Runnable
{
	public void run()
	{
		int a=0,b=1;
		int lim,sum=0;
		Scanner x=new Scanner(System.in);
		System.out.println("******** FIBONACCI SERIES *************");
		System.out.println("Enter the number of terms :");
		lim=x.nextInt();
		for(int i=0;i<lim;i++)
		{
			System.out.println(a+" ");
			sum=a+b;
			a=b;
			b=sum;
		}
	}
}
class even implements Runnable
{
	public void run()
	{
		Scanner x=new Scanner(System.in);
		int low,hi;
		System.out.println("********* EVEN NUMBERS IN A RANGE **********");
		System.out.println("Enter the lower range : ");
		low=x.nextInt();
		System.out.println("Enter the higher range : ");
		hi=x.nextInt();
		System.out.println("\n\n\n The Even Numbers between "+low+" and "+hi+" : ");
		for(int i=low;i<=hi;i++)
		{
			if(i%2!=0)
			continue;
		else
		{
			System.out.println("\n\n\n\n"+ i + " ");
		}
		}
	}
}	
		public class fibeven
		{
			public static void main(String args[]) throws InterruptedException
			{
				fibo obj1 = new fibo();
				Thread abc = new Thread(obj1);
				abc.start();
				even obj2 = new even();
				Thread xyz = new Thread(obj2);
				xyz.start();
			}
		}
