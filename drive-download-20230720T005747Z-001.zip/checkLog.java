import java.util.*;
class unameExc extends Exception
{
public unameExc(String msg)
{
super(msg);
}
}
class pwExc extends Exception
{
public pwExc(String msg)
{
super(msg);
}
}
public class checkLog
{
public static void main(String args[])
{
Scanner x=new Scanner(System.in);
String uname,pw;
System.out.println("Enter the username: ");
uname = x.next();
System.out.println("Enter the password: ");
pw = x.next();

int length=uname.length();
try
{
if(length<8)
throw new unameExc("Too short : min 8 chars required");
else if(!pw.equals("123"))
throw new pwExc("Password Incorrect");
else
System.out.println("Login Success ");
}
catch(unameExc u)
{
System.out.println(u);
}
catch(pwExc p)
{
System.out.println(p);
}
}
}
