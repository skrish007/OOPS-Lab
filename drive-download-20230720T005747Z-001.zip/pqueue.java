import java.util.*;
class pqueue
{
	public static void main(String args[])
	{
	PriorityQueue<Integer> pqueue = new PriorityQueue<Integer>();
	int a,b,c,d;
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the Integers:");
		a=x.nextInt();
		pqueue.add(a);
		b=x.nextInt();
		pqueue.add(b);
		c=x.nextInt();
		pqueue.add(c);
		d=x.nextInt();
		pqueue.add(d);
		System.out.println("Top Element :"+pqueue.peek());
		//print top ele. removing it from pqueue
		
		System.out.println("print top ele. removing it from pqueue :"+pqueue.poll());
		System.out.println("FinAl PQueue :"+pqueue.peek());
}
}