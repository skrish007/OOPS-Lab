import java.util.*;
import java.util.Deque;
public class deque
{
	public static void main(String args[])
	{
		Deque<Integer> deque = new ArrayDeque<Integer>();
		int a,b,c,d;
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the Integers:");
		a=x.nextInt();
		
		b=x.nextInt();
		
		deque.addFirst(a);
		deque.addLast(b);
		int first = deque.removeFirst();
		int last = deque.removeLast();
		
		System.out.println("First Element :"+first);
		System.out.println("Last Element :"+last);
	}
}