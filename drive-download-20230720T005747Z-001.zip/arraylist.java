import java.util.*;
import java.util.Collections;

public class arraylist
{
	public static void main(String args[])
	{
	String st;
	Scanner x = new Scanner(System.in);
	System.out.println("Enter the size of Arraylist");
	int n=x.nextInt();
	ArrayList<String> mylist = new ArrayList<String>();
	System.out.println("Enter the elements :");
	for(int i=0;i<n;i++)
	{
	
	st=x.next();
	mylist.add(st);
	}
	
	System.out.println("Enter the position you want to update:");
	int u=x.nextInt();
	System.out.println("Enter the element you want to add:");
	String e=x.next();
	mylist.set(u,e);
	System.out.println("Updated List");
	System.out.println(mylist);
	System.out.println("Enter the element to append:");
	String k=x.next();
	mylist.add(k);
	System.out.println("Updated List");
	System.out.println(mylist);
	System.out.println("Enter the position you want to remove:");
	int r=x.nextInt();
	mylist.remove(r);
	System.out.println("Updated List");
	System.out.println(mylist);
	System.out.println("********SORTING********");
	System.out.println("After Sorting :");
	Collections.sort(mylist);
	for(String i : mylist)
	{
		System.out.println(i);
	}
}
}
	

	/*String a=x.next();
	String b=x.next();
	String c=x.next();
	String d=x.next();
	mylist.add(a);
	mylist.add(b);
	mylist.add(c);
	mylist.add(d);
	;
	
	System.out.println("Enter the position you want to update:");
	int u=x.nextInt();
	System.out.println("Enter the element you want to add:");
	String e=x.next();
	mylist.set(u,e);
	System.out.println("Updated List");
	System.out.println(mylist);
	System.out.println("Enter the element to append:");
	String k=x.next();
	mylist.add(k);
	System.out.println("Updated List");
	System.out.println(mylist);
	System.out.println("Enter the position you want to remove:");
	int r=x.nextInt();
	mylist.remove(r);
	System.out.println("Updated List");
	System.out.println(mylist);*/
	