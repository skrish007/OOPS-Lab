package arithmetic;

import java.util.Scanner;

interface Operations 
{
	public void input();
    public void add();
    public void sub();
    public void multi();
    public void div();
    
}

public class Arithmetic implements Operations 
{
    double n1, n2,a,s,m,d;
    
    public void input() 
	{
        Scanner x = new Scanner(System.in);
        System.out.println("Enter first number: ");
        n1 = x.nextDouble();
        System.out.println("Enter second number: ");
        n2 = x.nextDouble();
    }
    
    public void add() 
	{
		a=n1+n2;
		System.out.println("\n\n******* SUM *******\n");
        System.out.println(+ n1 + " + " + n2 + " = " +a);
    }
    
    public void sub() 
	{
        a=n1+n2;
		System.out.println("\n\n******* DIFFERENCE *******\n");
        System.out.println(+ n1 + " - " + n2 + " = " +s);
    }
    
    public void multi() 
	{
        a=n1+n2;
		System.out.println("\n\n******* PRODUCT *******\n");
        System.out.println( + n1 + " x " + n2 + "= " +m);
    }
    
    public void div() 
	{
        if(n2 == 0) {
            System.out.println("ERROR!");
        }
		else 
		{
            d=n1/n2;
		System.out.println("\n\n******* DIVISION *******\n");
        System.out.println(+ n1 + " / " + n2 + " = " +d);
        }
    }
    
    public static void main(String[] args)
	{
        Arithmetic obj = new Arithmetic();
        obj.input();
        obj.add();
        obj.sub();
        obj.multi();
        obj.div();
    }
}
