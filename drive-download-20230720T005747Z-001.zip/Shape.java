package Graphics;

import java.util.Scanner;

interface Area {
	public void rec();
	public void tri();
	public void cir();
	public void sqr();
	public void getTri();
	public void getCir();
	public void getSqr();
	public void getRec();
}

public class Shape implements Area {
	double ra, ta, sa, ca, rl, rb, th, tb, s, rad;
	
	public void getRec() {
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the length of rectangle: ");
		rl = x.nextDouble();
		System.out.println("Enter the breadth of rectangle: ");
		rb = x.nextDouble();
	}
	
	public void rec() {
		ra = rl * rb;
		System.out.print("\n\n******* RECTANGLE *******");
		System.out.print("\n Area: " + ra);
	}
	
	public void getTri() {
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the base of triangle: ");
		tb = x.nextDouble();
		System.out.println("Enter the height of triangle: ");
		th = x.nextDouble();
	}
	
	public void tri() {
		ta = (0.5 * tb * th);
		System.out.print("\n\n******* TRIANGLE *******");
		System.out.print("\n Area: " + ta);
	}
	
	public void getCir() {
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the radius of circle: ");
		rad = x.nextDouble();
	}
	
	public void cir() {
		ca = (3.14 * rad * rad);
		System.out.print("\n\n******* CIRCLE *******");
		System.out.print("\n Area: " + ca);
	}
	
	public void getSqr() {
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the side of square: ");
		s = x.nextDouble();
	}
	
	public void sqr() {
		sa = s * s;
		System.out.print("\n\n******* SQUARE *******");
		System.out.print("\n Area: " + sa);
	}
	
	public static void main(String args[]) {
		Shape obj = new Shape();
		obj.getTri();
		obj.tri();
		obj.getCir();
		obj.cir();
		obj.getSqr();
		obj.sqr();
		obj.getRec();
		obj.rec();
	}
}
