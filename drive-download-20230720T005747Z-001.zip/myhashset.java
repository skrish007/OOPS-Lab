import java.util.*;
import java.util.HashSet;

public class myhashset {
  public static void main(String[] args) {
    HashSet<String> myhashset = new HashSet<String>();
	String a,b,c,d;
	Scanner x = new Scanner(System.in);
	System.out.println("Enter the Strings:");
	a=x.next();
	b=x.next();
	c=x.next();
	d=x.next();
	
    myhashset.add(a);
    myhashset.add(b);
    myhashset.add(c);
    myhashset.add(d);
   
    System.out.println(myhashset);
  }
}