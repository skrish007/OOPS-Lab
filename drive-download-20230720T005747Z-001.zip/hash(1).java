
import java.util.HashSet;

public class Main {
  public static void main(String[] args) {
    HashSet<String> myhashset = new HashSet<String>();
    myhashset.add(a);
    myhashset.add(b);
    myhashset.add(c);
    myhashset.add(d);
   
    System.out.println(myhashset);
  }
}