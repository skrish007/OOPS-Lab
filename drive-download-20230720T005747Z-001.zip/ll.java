import java.util.*;
import java.util.LinkedList;
public class ll
{
	public static void main(String args[])
	{
		LinkedList<String> list = new LinkedList<String>();
		String a,b,c,d;
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the Strings:");
		a=x.next();
		list.add(a);
		b=x.next();
		list.add(b);
		c=x.next();
		list.add(c);
		d=x.next();
		list.add(d);
		
		System.out.println("Original LinkedList :"+list);
		list.clear();
		System.out.println("Updated List :"+list);
	}
}