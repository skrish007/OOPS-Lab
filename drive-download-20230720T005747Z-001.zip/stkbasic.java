import java.util.*;
public class stkbasic
 {
	public static void main(String args [])
	{
		Stack <String> mystack = new Stack <String>();
		String a,b,c,d;
		Scanner x = new Scanner(System.in);
		System.out.println("Enter the Strings:");
		a=x.next();
		mystack.add(a);
		b=x.next();
		mystack.add(b);
		c=x.next();
		mystack.add(c);
		d=x.next();
		mystack.add(d);
		System.out.println("Stack :"+mystack);
		System.out.println("Stack Removal");
		System.out.println("Enter the position you want to remove:");
		int y=x.nextInt();	
		String remo=mystack.remove(y);
		System.out.println("Removed element :"+remo);
		System.out.println("Stack after deletion :"+mystack);
	}
}