import java.util.*;
class Multi extends Thread
{
	public void run()
	{
		int n=7;
		System.out.println("******** MULTIPLICATION TABLE *************");
		for(int i=1;i<=10;i++)
		{
		System.out.println(n+ " * "+ i +" =  "+n*i);
		}
	}
}
		class PrimeNo extends Thread
		{
			public void run()
			{
				int a, b,i,j;
				System.out.println("*********** PRIME NUMBERS ***********");
				System.out.println("First Number :");
				Scanner x= new Scanner(System.in);
				a=x.nextInt();
				System.out.println("Second Number :");
				b=x.nextInt();
				System.out.println("*********** PRIME NUMBERS ***********");
				System.out.println("Between "+a+" and "+b+" : ");
				for(i=a; i<=b; i++)
				{
				for(j=2; j<=i ; j++)
				{
				if(i%j==0)
				{
				break;
				}
				}
				if(i==j)
				{
				System.out.println(j);
				}
				}
			} 
		}
		
		public class multable
		{
			public static void main(String args[]) throws InterruptedException
			{
				Multi m = new Multi();
				m.start();
				m.sleep(400);
				PrimeNo p = new PrimeNo();
				p.start();
				p.sleep(400);
			}
		}