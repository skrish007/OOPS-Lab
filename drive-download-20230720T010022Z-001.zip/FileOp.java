import java.io.FileOutputStream;
public class FileOp
{
	public static void main(String args[])
	{
		try
		{
			FileOutputStream fout= new FileOutputStream("D:\\testout.txt");
			fout.write(75);
			fout.close();
			System.out.println("SUCCESS");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}