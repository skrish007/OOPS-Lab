import java.io.FileOutputStream;
public class filewrite
{
	public static void main(String args[])
	{
		try
		{
			FileOutputStream fout= new FileOutputStream("D:\\testout.txt");
			String s="Hakuna Matata";
			byte x[]=s.getBytes();
			fout.write(x);
			fout.close();
			System.out.println("SUCCESS");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}