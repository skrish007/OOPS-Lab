import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class keyprgm extends Applet implements KeyListener {
 String msg = "Typed Key is :";
 int x = 30, y = 50;

 public void init() {
  addKeyListener(this);
  requestFocus();
 }

 public void keyTyped(KeyEvent z) {
  msg += z.getKeyChar() + " ";
  repaint();
 }

 public void keyReleased(KeyEvent z) {
  showStatus("Key increase");
 }

 public void keyPressed(KeyEvent z) {
  showStatus("Key decrease");
 }

 public void paint(Graphics q) {
  q.drawString(msg, x, y);
 }
}