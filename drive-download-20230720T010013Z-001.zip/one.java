import java.awt.*;

import java.applet.*;


public class one extends Applet {
    public void paint(Graphics g) {
        // Draw a circle
        g.setColor(Color.red);
        g.drawOval(50, 50, 100, 100);

        // Draw a rectangle
        g.setColor(Color.green);
        g.drawRect(200, 50, 150, 100);

        // Draw a line
        g.setColor(Color.blue);
        g.drawLine(50, 200, 350, 200);
    }
}

/*
<applet code="one.class" width="500" height="500">
</applet>
*/