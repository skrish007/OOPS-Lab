import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.*;

public class CX extends Applet implements ItemListener {
    int n;
    private Choice choice;
    public void init() {
        choice = new Choice();
        choice.addItem("Choose");
        choice.addItem("R E C T A N G L E");
        choice.addItem("T R I A N G L E");
        choice.addItem("S Q U A R E");
        choice.addItem("C I R C L E");
        choice.addItemListener(this);

        add(choice);
    }

    public void itemStateChanged(ItemEvent e) {
        n = choice.getSelectedIndex();
        repaint();
    }
     public void paint(Graphics x)
     {
         if(n==0)
         {
             
         }
         if(n==1)
         {
             x.setColor(Color.green);
             x.fillRect(50, 50, 200, 100);
         }
         if(n==2)
         {

             int[] xPoints = {50, 150, 100}; 
             int[] yPoints = {150, 150, 50};
             x.setColor(Color.red);             
             x.fillPolygon(xPoints, yPoints, 3);
        
         }
         if(n==3)
         {
             x.setColor(Color.blue);
             x.fillRect(50,50,100,100);
         }
         if(n==4)
         {
             x.setColor(Color.pink);
             x.fillOval(70,30,100,100);
         }
         
     }
}
/*
<applet code="CX.class" width="500" height="500"> 
</applet> 
*/