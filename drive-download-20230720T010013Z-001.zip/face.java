import java.applet.*;
import java.awt.*;
public class face extends Applet
{
	public void paint(Graphics x)
	{
		x.drawOval(200,200,150,150);
		x.fillOval(240,240,20,20);
		x.fillOval(295,240,20,20);
		x.drawArc(240,260,70,70,0,-180);
	}
}