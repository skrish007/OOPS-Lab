import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class ml extends Applet implements
        MouseListener, MouseMotionListener {
    int mx = 0;
    int my = 0;
    String msg = "";

    public void init() {
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void mouseClicked(MouseEvent x) {
        mx = 20;
        my = 40;
        msg = "Mouse Clicked";
        repaint();
    }

    public void mousePressed(MouseEvent x) {
        mx = 30;
        my = 60;
        msg = "Mouse Pressed";
        repaint();
    }

    public void mouseReleased(MouseEvent x) {
        mx = 30;
        my = 60;
        msg = "Mouse Released";
        repaint();
    }

    public void mouseEntered(MouseEvent x) {
        mx = 40;
        my = 80;
        msg = "Mouse Entered";
        repaint();
    }

    public void mouseExited(MouseEvent x) {
        mx = 40;
        my = 80;
        msg = "Mouse Exited";
        repaint();
    }

    public void mouseDragged(MouseEvent x) {
        mx = x.getX();
        my = x.getY();
        showStatus("Currently mouse dragged" + mx + " " + my);
        repaint();
    }

    public void mouseMoved(MouseEvent x) {
        mx = x.getX();
        my = x.getY();
        showStatus("Currently mouse is at" + mx + " " + my);
        repaint();
    }

    public void paint(Graphics p) {
        p.drawString("Handling Mouse Events", 30, 20);
        p.drawString(msg, 60, 40);
    }
}
/*
 * <applet code="ml.class" width="500" height="200">
 * </applet>
 */