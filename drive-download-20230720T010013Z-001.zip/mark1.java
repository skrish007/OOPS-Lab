import java.applet.*;

import java.awt.*;

import java.awt.event.*;
public class mark1 extends Applet implements ActionListener{
    Label l1,l2,l3,l4,l5,l6;
    TextField t1,t2,t3,t4,t5,t6;
    Button btn;
    public void init(){
        l1 = new Label("Enter Mark 1 :");
        t1 = new TextField();
        l2 = new Label("Enter Mark 2 :");
        t2 = new TextField();
        l3 = new Label("Enter Mark 3 :");
        t3 = new TextField();
        l4 = new Label("Enter Mark 4 :");
        t4 = new TextField();
        l5 = new Label("Enter Mark 5 :");
        t5 = new TextField();
        l6 = new Label("PERCENTAGE :");
        t6 = new TextField();
        btn = new Button("  RESULT  ");
        setLayout(null);
        l1.setBounds(50,50,80,20);
        t1.setBounds(150,50,110,20);
        l2.setBounds(50,80,80,20);
        t2.setBounds(150,80,110,20);
        l3.setBounds(50,110,80,20);
        t3.setBounds(150,110,110,20);
        l4.setBounds(50,140,80,20);
        t4.setBounds(150,140,110,20);
        l5.setBounds(50,170,80,20);
        t5.setBounds(150,170,110,20);
        l6.setBounds(50,200,100,20);
        t6.setBounds(150,200,100,20);
        btn.setBounds(50,230,90,30);
        add(l1);
        add(l2);
        add(l3);
        add(l4);
        add(l5);
        add(l6);
        add(t1);
        add(t2);
        add(t3);
        add(t4);
        add(t5);
        add(t6);
        add(btn);
        btn.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e)
    {
        float m1,m2,m3,m4,m5,Percentage,total;
        m1=Float.parseFloat(t1.getText());
        m2=Float.parseFloat(t2.getText());
        m3=Float.parseFloat(t3.getText());
        m4=Float.parseFloat(t4.getText());
        m5=Float.parseFloat(t5.getText());
        total = m1+m2+m3+m4+m5;
        Percentage =(total*100)/500;
        t6.setText(String.valueOf(Percentage));
        repaint();

    }
    public void paint(Graphics g){
        float p;
        p=Float.parseFloat(t6.getText());
        if(p>50)
        {
            g.drawOval(80,300,240,240);
            g.drawOval(130,350,50,50);
            g.drawOval(220,350,50,50);
            g.drawArc(150,400,100,90,200,150);
        }
        else{
            g.drawOval(80,300,240,240);
            g.drawOval(130,350,50,50);
            g.drawOval(220,350,50,50);
            g.drawArc(150,450,100,90,15,150);
        }
    }
}

/*
<applet code="mark1.class" width="500" height="500">
</applet>
*/