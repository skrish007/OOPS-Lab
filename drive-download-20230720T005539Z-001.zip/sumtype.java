import java.util.Scanner;
public class sumtype{
    public void sum(int i ,int j){
        System.out.println("Sum : " +(i+j));
    }
    public void sum(int n){
       int s=0;
       while(n>0){
            int d=n%10;
            s=s+d;
			n=n/10;
	   }
            System.out.println("Sum of digits :" +s);
       }
    
    public void sum(String u ,String v){
        System.out.println("Sum of 2 strings :" + (u+v));
    }
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        sumtype x=new sumtype();
        int i,j,n,op=0;
        String u,v;
		while(op!=4)
		{
         System.out.println("\n*******SUM TYPES********\nSelect Your Operation \n 1)Sum of 2 numbers\n 2)Sum of digits of a number\n 3)Sum of 2 strings\n 4)Exit ");
         op=sc.nextInt();
         switch (op){
            case 1:
                System.out.println("The First Number :");
                i=sc.nextInt();
                System.out.println("The Second Number :");
                j=sc.nextInt();
                x.sum(i,j);
                break;
            case 2:
                System.out.println("Number: ");
                n=sc.nextInt();
                x.sum(n);
                break;
            case 3:
                System.out.println("The First  String :");
                u=sc.next();
                System.out.println("The Second String :");
                v=sc.next();
                x.sum(u,v);
                break;
			case 4:
				System.exit(0);
			default:
				System.out.println("Invalid Choice\n");
                break;
         }
		}
    }
}

