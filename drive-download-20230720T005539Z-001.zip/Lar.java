import java.util.Scanner;

public class Lar 
{
    public void large(int x, int y) 
	{
        if (x > y) 
		{
            System.out.println("The Largest Number is: " + x);
        } 
		else 
		{
            System.out.println("The Largest Number is: " + y);
        }
    }

    public void large(int a, int b, int c) 
	{
        if ((a > b) && (a > c)) 
		{
            System.out.println("The Largest Number is: " + a);
        } 
		else if ((b > a) && (b > c)) 
		{
            System.out.println("The Largest Number is: \n" + b);
        } 
		else 
		{
            System.out.println("The Largest Number is: \n" + c);
        }
    }

    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Lar x = new Lar();
        int a, b, c, ch=0;
        while(ch != 3)
		{
            System.out.println("\n--------------SUM--------------\n");
            System.out.println("Select Your Operation");
            System.out.println("1) Find the largest of two numbers");
            System.out.println("2) Find the largest of three numbers");
            System.out.println("3) Exit\n");
            ch = sc.nextInt();
            switch (ch) 
			{
                case 1:
                    System.out.println("Enter the First Number:");
                    a = sc.nextInt();
                    System.out.println("Enter the Second Number:");
                    b = sc.nextInt();
                    x.large(a, b);
                    break;
                case 2:
                    System.out.println("Enter the First Number:");
                    a = sc.nextInt();
                    System.out.println("Enter the Second Number:");
                    b = sc.nextInt();
                    System.out.println("Enter the Third Number:");
                    c = sc.nextInt();
                    x.large(a, b, c);
                    break;
                case 3:
                    System.exit(0);
                default:
                    System.out.println("Invalid Choice\n");
                    break;
            }
        }
    }
}