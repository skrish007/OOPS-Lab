import java.util.*;

class Box
{
	int l,w,h;
	Box()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.println("************ USER INPUT *****************\n");
		 System.out.print("Enter the length:");
		 l = x.nextInt(); 
		 
		  System.out.print("Enter the width:");
		 w = x.nextInt(); 
		 
		  System.out.print("Enter the height:");
		 h = x.nextInt(); 
		 
		 
	}
}


class Cupboard extends Box
{
	int n;
	Cupboard()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.print("Enter no of shelves:");
		 n = x.nextInt();   	 
	}
	void display()
	{
		System.out.println("\n************ CUPBOARD *****************\n");
		System.out.println("length :"+l);
		System.out.println("width :"+w);
		System.out.println("height :"+h);
		System.out.println("no of shelves:"+n);
	}
}

public class p10
{
  public static void main(String args[])
	{
		Cupboard obj = new Cupboard();
        obj.display();		
	}
}