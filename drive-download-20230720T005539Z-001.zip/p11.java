import java.util.*;

class Employee
{
	int empid;
	String name;
	Employee()
	{
		 Scanner sc = new Scanner(System.in);
		 System.out.println("************ FILL UP *****************");
		 System.out.print("Enter Employee id :");
		 empid = sc.nextInt(); 
		 
		 System.out.print("Enter Name :");
		 name = sc.next();
		 
	}
}
class Worker extends Employee
{
	int wage;
	Worker()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Daily Wage :");
		wage = sc.nextInt(); 
	}
	void show()
	{
		System.out.println("************ Employee Info *****************");
		System.out.println(" ID :"+empid);
		System.out.println(" Name :"+name);
		System.out.println(" Wage :"+wage);
		
	}
}



public class p11
{
  public static void main(String args[])
	{
		int n;
		Scanner x= new Scanner(System.in);
		System.out.println ("\nEnter the number of workers:");
		n= x.nextInt();
		Worker obj[] = new Worker[n];
		System.out.println ("\nEnter the details of" +n+" employees:\n");	
			
			for(int i=0;i<n;i++)
			{
				
				obj[i]=new Worker();
			}
			for(int i=0;i<n;i++)
			{
			obj[i].show();
			}
       
	}
}