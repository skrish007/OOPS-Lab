import java.util.*;

class Student
{
	int rno;
	String name;
	
	Student()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.print("Enter Roll Number :");
		 rno = x.nextInt();
		 
		 System.out.print("Enter Name :");
		 name = x.next();
		 
	}
	
}
class Test extends Student
{
	int marks1;
    int marks2;
	
	Test()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.println("************ FILL UP *****************");
		 System.out.print("Enter first mark:");
		 marks1 = x.nextInt();
		 
		 System.out.print("Enter second mark :");
		 marks2 = x.nextInt();
		 
	}
	
}
class Result extends Test
{
	int total;
	void total()
	{
		total = marks1+marks2;
		System.out.println("\n\n************ Student Info *****************");
		System.out.println("Rollno :"+rno);
		System.out.println("Name :"+name);
		System.out.println("Total mark obtained :\n"+total);
	}
	
	
}
class p12
{
  public static void main(String args[])
	{
		Result obj = new Result();
        obj.total();		
	}
}