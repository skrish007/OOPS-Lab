import java.util.Scanner;
class Person{
    Scanner obj=new Scanner(System.in);
    String name,gen,add;
    int age;
    Person(){
        System.out.println("Enter The Name :");
        name=obj.next();
        System.out.println("Enter The Gender:");
        gen=obj.next();
        System.out.println("Enter The Address :");
        add=obj.next();
        System.out.println("Enter The Age :");
        age=obj.nextInt();
    }
}
class Employee extends Person{
	int eid,sal;
	String cpny,qf;
	Employee(){
        System.out.println("Enter The Employee Id :");
        eid=obj.nextInt();
        System.out.println("Enter The Company Name :");
        cpny=obj.next();
        System.out.println("Enter The Employee Salary :");
        sal=obj.nextInt();
        System.out.println("Enter The Employee  Qualification:");
        qf=obj.next();
	}
}
class Teacher2 extends Employee{
    String sub,dep;
    int tid;
     Teacher2(){
			System.out.println("*********** Fill in **************\n");
            System.out.println("Enter the Teacher id:");
			tid=obj.nextInt();
			System.out.println("Enter the Department:");
			dep=obj.next();
			System.out.println("Enter the Subject");
			sub=obj.next();
     }
     public void display(){
		
        System.out.println("\n*********** Info **************\n");
        System.out.println("Name  :"+name);
        System.out.println("Gender  :"+gen);
        System.out.println("Address  :"+add);
        System.out.println("Age  :"+age);
        System.out.println("Employee ID   :"+eid);
        System.out.println("Company :"+cpny);
        System.out.println("Salary :"+sal);
        System.out.println("Qualification :"+qf);
        System.out.println("Teacher ID  :"+tid);
        System.out.println("Department :"+dep);
        System.out.println("Subject  :"+sub);
     }
    public static void main(String args[]){
        Scanner ob=new Scanner(System.in);
        int n;
        System.out.println("Enter The Number of Teachers:");
        n=ob.nextInt();
        Teacher2 t[]=new Teacher2[n];
        for(int i=0;i<n;i++)
		{
		    t[i]=new Teacher2();
		}
		for(int i=0;i<n;i++){
            t[i].display();
		}

    }
}
