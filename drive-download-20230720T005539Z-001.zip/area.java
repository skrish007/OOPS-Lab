import java.util.Scanner;
class findarea
{
	findarea()
	{
		System.out.println("********* AREA OF TRIANGLE AND RECTANGLE*************");
		
		
	}
}
class rectangle extends findarea
{
	int l,b;
	void display()
	{
		System.out.println("********* RECTANGLE*************");
		System.out.println("Area : "+(l*b));
	}
	rectangle()
	{
		Scanner x=new Scanner(System.in);
		System.out.println("Enter length of rectangle:");
		l=x.nextInt();
		System.out.println("Enter breadth of rectangle:");
		b=x.nextInt();
	}
}
class triangle extends findarea
{
	int b;
	int h;
	
	void display1()
	{
		System.out.println("******** TRIANGLE ********");
		System.out.println("Area :"+(0.5*b*h));
	}
	triangle()
	{
		System.out.println("Enter base of triangle:");
		Scanner x=new Scanner(System.in);
		b=x.nextInt();
		System.out.println("Enter the height of triangle:");
		h=x.nextInt();
	}
	
}
public class area
{
	public static void main(String args[])
	{
		triangle t1=new triangle();
		t1.display1();
		rectangle r1=new rectangle();
		r1.display();
		
	}
}