import java.util.Scanner;
public class Avg
{
    public void avg(int i1 ,int i2){
             System.out.println("Average : " +(i1+i2)/2);
    }
    public void avg(double d1 ,double d2){
        System.out.println("Average  : " +(d1+d2)/2);
    }
    public void avg(float f1 ,float f2,float f3){
        System.out.println("Average : " +(f1+f2+f3)/3);
    }
    public static void main(String args[])
	{
        Scanner sc= new Scanner(System.in);
        Avg x=new Avg();
        int i1,i2,op=0;
        double d1,d2;
        float f1,f2,f3;
         while(op != 4)
		{
            System.out.println("\n--------------AVERAGE--------------\n");
            System.out.println("Select Your Operation");
            System.out.println("1) Find the average of two integers");
			System.out.println("2) Find the average of two double values");
            System.out.println("3) Find the average of three float values");
            System.out.println("4) Exit\n");
            op = sc.nextInt();
         switch (op)
		 {
            case 1:
                System.out.println("The First Number :");
                i1=sc.nextInt();
                System.out.println("The Second Number :");
                i2=sc.nextInt();
                x.avg(i1,i2);
                break;
            case 2:
                System.out.println("The First Number :");
                d1=sc.nextDouble();
                System.out.println("The Second Number :");
                d2=sc.nextDouble();
                x.avg(d1,d2);
                break;
            case 3:
                System.out.println("The First Number :");
                f2=sc.nextFloat();
                System.out.println("The Second Number :");
                f1=sc.nextFloat();
                System.out.println("The Third Number :");
                f3=sc.nextFloat();
                x.avg(f2,f1,f3);
                break;
			case 4:
			    System.exit(0);
			default:
				System.out.println("Invalid Choice\n");
                break;
         }
		}

	}
}
