import java.util.*;

class Student
{
	int rno;
	String name;
	
	Student()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.println("\n\n************ Fill up *****************\n");
		 System.out.print("Enter Rollno:");
		 rno = x.nextInt();
		 
		 System.out.print("Enter Name :");
		 name = x.next();
		 
	}
	
}
class Marks extends Student
{
	int m1,m2,m3;
	double t;
	double p;
	Marks()
	{
		 Scanner x = new Scanner(System.in);
	
		 System.out.print("Enter Mark 1 :");
		 m1 = x.nextInt();
		  System.out.print("Enter Mark 2 :");
		 m2 = x.nextInt();
		  System.out.print("Enter Mark 3 :");
		 m3 = x.nextInt();
		 
		 
		 
	}
	void total()
	{
		t = m1+m2+m3;
		p = ((t/300)*100);
		System.out.println("\n\n************ Student Info *****************\n");
		System.out.println("Rollno :"+rno);
		System.out.println("Name :"+name);
		System.out.println("Total mark obtained :"+t);
		System.out.println("Total percentage obtained :"+p);
	}
	
	
}
public class p8
{
  public static void main(String args[])
	{
		Marks obj = new Marks();
        obj.total();		
	}
}