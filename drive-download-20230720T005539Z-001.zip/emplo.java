import java.util.Scanner;
class EmployeeClass
{
	int eid;
	String eadd;
	int esal;
	String ename;
	EmployeeClass()
	{
		Scanner x= new Scanner(System.in);
		System.out.println("************ FILL UP ************** ");
		System.out.println("Enter the Employee ID: ");
		eid=x.nextInt();
		System.out.println("Enter the Employee Name: ");
		ename=x.next();
		System.out.println("Enter the Employee Address: ");
		eadd=x.next();
		System.out.println("Enter the Employee Salary: ");
		esal=x.nextInt();
	}
}
class TeacherClass extends EmployeeClass {
    String dept;
    String sub;

    TeacherClass() {
        super();
        Scanner x = new Scanner(System.in);
		System.out.println("\n\n************ FILL UP ************** ");
		System.out.println("Enter the Department:");
		dept=x.next();
		System.out.println("Enter the Subject taught: ");
		sub=x.next();
	}

	void show()
	{
	System.out.println("************ Employee Info *****************");
	System.out.println("ID: "+eid);
	System.out.println("Name: "+ename);
	System.out.println("Address: "+eadd);
	System.out.println("Salary: "+esal);
	System.out.println ("\n\n******** TEACHER INFO **********");
	System.out.println ("DEPARTMENT :"+dept);
	System.out.println ("SUBJECT:"+sub);
	}
	}
	public class emplo
	{
		public static void main(String args[])
		{
			int n;
			Scanner x= new Scanner(System.in);
			System.out.println ("\nEnter the number of records to be printed:");
			n= x.nextInt();
			TeacherClass obj[] =new TeacherClass[n];
			System.out.println ("\nEnter the details of" +n+" employees:\n");	
			
			for(int i=0;i<n;i++)
			{
				obj[i]=new TeacherClass();
			}
			for(int i=0;i<n;i++)
			{
			obj[i].show();
			}
		}
	}