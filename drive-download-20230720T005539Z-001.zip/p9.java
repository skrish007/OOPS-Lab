
import java.util.*;

class Employee
{
	int empid;
	String name;
	String des;
	Employee()
	{
		 Scanner x = new Scanner(System.in);
		 System.out.println("\n************ FILL IN *****************\n");
		 System.out.print("Enter Employee ID :");
		 empid = x.nextInt(); 
		 
		 System.out.print("Enter Name :");
		 name = x.next();
		 System.out.print("Enter Designation :");
		 des = x.next();
		 
	}
}
class Salary extends Employee
{
	double b,hra,da,gross;
	Salary()
	{
		Scanner x = new Scanner(System.in);
		System.out.print("Enter Basic pay :");
		b = x.nextDouble(); 
		da =b*35/100;
		hra = b*15/100;
		gross = b+da+hra;
	}
	void display()
	{
		System.out.println("\n************ EMPLOYEE INFO *****************\n");
		System.out.println("ID :"+empid);
		System.out.println("Name :"+name);
		System.out.println("Designation :"+des);
		System.out.println("DA :"+da);
		System.out.println("HRA :"+hra);
		System.out.println("Gross :"+gross);
		
		
	}
}
public class p9
{
  public static void main(String args[])
	{
		Salary obj = new Salary();
        obj.display();		
	}
}