import java.util.*;

public class Shapes {
    // CIRCLE
    public void area(double r) {
        double ac = 3.14 * r * r;
        System.out.println("******CIRCLE********");
        System.out.println("AREA :\n" + ac);
    }

    // TRIANGLE
    public void area(int b, int h) {
        double at = (0.5 * b * h); 
        System.out.println("******TRIANGLE********");
        System.out.println("AREA :\n" + at);
    }

    // Square
    public void area(float s) {
        double as = (s * s);
        System.out.println("******SQUARE********");
        System.out.println("AREA :\n" + as);
    }

    // Rectangle
    public void area(double l, double w) {
        double ar = (l * w);
        System.out.println("******RECTANGLE********");
        System.out.println("AREA :\n" + ar);
    }

	//Parallelogram
    public void area(float bs, float ht) {
        double ap = (bs * ht);
        System.out.println("******Parallelogram********");
        System.out.println("AREA :\n" + ap);
    }
	
	// Trapezium
    public void area(int s1, int s2, int height) {
        double atrap = (0.5 *(s1+s2)*height);
        System.out.println("******Trapezium********");
        System.out.println("AREA :\n" + atrap);
    }
	
	// Ellipse
    public void area(double mj,float mi) {
        double ae = (3.14 * mj *mi);
        System.out.println("******Ellipse********");
        System.out.println("AREA :\n" + ae);
    }
    public static void main(String args[]) {
        Scanner x = new Scanner(System.in);
        Shapes sp = new Shapes();

        System.out.println("Enter the radius of Circle:");
        double r = x.nextDouble();
        System.out.println("Enter the base of Triangle:");
        int b = x.nextInt();
        System.out.println("Enter the height of Triangle:");
        int h = x.nextInt();
        System.out.println("Enter the side of Square:");
        float s = x.nextFloat();
        System.out.println("Enter the length of Rectangle:");
        double l = x.nextDouble();
        System.out.println("Enter the breadth of Rectangle:");
        double w = x.nextDouble();
        System.out.println("Enter the height of Parallelogram:");
        float ht = x.nextFloat();
		System.out.println("Enter the base of Parallelogram:");
        float bs = x.nextFloat();
        System.out.println("Enter the height of Trapezium:");
        int height = x.nextInt();
		System.out.println("Enter the length of first side of Trapezium:");
        int s1 = x.nextInt();
		System.out.println("Enter the length of second side of Trapezium:");
        int s2 = x.nextInt();
		System.out.println("Enter the major axis of Ellipse:");
        double mj = x.nextDouble();
        System.out.println("Enter the minor axis of Ellipse:");
        float mi = x.nextFloat();
        

        sp.area(r);
        sp.area(b, h);
        sp.area(s);
        sp.area(l, w);
		sp.area(bs,ht);
		sp.area(s1,s2,height);
		sp.area(mj,mi);

        
    }
}
