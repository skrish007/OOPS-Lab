import java.util.*;

public class Vol {
    // CUBOID
    public void vol(int len, int wid, int ht) {
        double vcud = (len * wid *ht);
        System.out.println("******CUBOID********");
        System.out.println("VOLUME :\n" + vcud);
    }
    // CYLINDER
    public void vol(double r, int h) {
        double vcyl = (3.14 * r * r * h); 
        System.out.println("******CYLINDER********");
        System.out.println("VOLUME :\n" + vcyl);
    }
	// CONE
    public void vol(float rcon, int conh) {
        double vcon = ((0.333) * 3.14 * rcon * rcon * conh); 
        System.out.println("******CONE********");
        System.out.println("VOLUME :\n" + vcon);
    }
    // CUBE
    public void vol(float s) {
        double vcube = (s * s * s);
        System.out.println("******CUBE********");
        System.out.println("VOLUME :\n" + vcube);
    }

    // Prism
    public void vol(double ba, double pht) {
        double vprism = (ba * pht);
        System.out.println("******PRISM********");
        System.out.println("VOLUME :\n" + vprism);
    }
	// SPHERE
    public void vol(double rad) {
        double vsp = ((1.333) * 3.14 * rad * rad * rad); 
        System.out.println("******SPHERE********");
        System.out.println("VOLUME :\n" + vsp);
    }
	//Pyramid
    public void vol(float pyba, float pyht) {
        double vpy = ((0.333)* pyba * pyht);
        System.out.println("******Pyramid********");
        System.out.println("VOLUME :\n" + vpy);
    }
	// Ellipsoid
    public void vol(float m1, float m2, float m3) {
        double vsqp = ((1.333)* m1 * m2 * m3);
        System.out.println("******Ellipsoid********");
        System.out.println("VOLUME :\n" + vsqp);
    }
	// SQ.PYRAMID
    public void vol(int sql, int sqw, float sqht) {
        double vsqp = ((0.333)* sql * sqw * sqht);
        System.out.println("******SQUARE PYRAMID********");
        System.out.println("VOLUME :\n" + vsqp);
    }
	
	
	
    public static void main(String args[]) {
        Scanner x = new Scanner(System.in);
        Vol sp = new Vol();
		System.out.println("Enter the length of Cuboid:");
        int len = x.nextInt();;
        System.out.println("Enter the breadth of Cuboid:");
        int wid = x.nextInt();
        System.out.println("Enter the height of Cuboid:");
        int ht = x.nextInt();
        System.out.println("Enter the radius of Cylinder:");
        double r = x.nextDouble();
		System.out.println("Enter the height of Cylinder:");
        int h = x.nextInt();
		System.out.println("Enter the radius of Cone:");
        float rcon = x.nextFloat();
		System.out.println("Enter the height of Cone:");
        int conh = x.nextInt();
        
        System.out.println("Enter the side of Cube:");
        float s = x.nextFloat();
        System.out.println("Enter the base area of Prism:");
        double ba = x.nextDouble();
        System.out.println("Enter the height of Prism:");
        double pht = x.nextDouble();
		System.out.println("Enter the radius of Sphere:");
        double rad = x.nextDouble();
        System.out.println("Enter the height of Pyramid:");
        float pyht = x.nextFloat();
		System.out.println("Enter the base area of Pyramid:");
        float pyba = x.nextFloat();
		System.out.println("Enter the length of Square Pyramid:");
        int spl = x.nextInt();;
        System.out.println("Enter the width of Square Pyramid:");
        int spw = x.nextInt();
        System.out.println("Enter the height of Square Pyramid:");
        float spht = x.nextFloat();
		System.out.println("Enter the length of first minor axis of Ellipsoid:");
        float m1 = x.nextFloat();
		System.out.println("Enter the length of second minor axis of Ellipsoid:");
        float m2 = x.nextFloat();
		System.out.println("Enter the length of third minor axis of Ellipsoid:");
        float m3 = x.nextFloat();;
        
		sp.vol(len,wid,ht);
        sp.vol(r,h);
		sp.vol(rcon,conh);
        sp.vol(s);
        sp.vol(ba, pht);
		sp.vol(rad);
		sp.vol(pyba,pyht);
		sp.vol(m1,m2,m3);
		sp.vol(spl,spw,spht);
		
		

        
    }
}
